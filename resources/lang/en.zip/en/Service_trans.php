<?php

return [

    'New_Service' => 'New_Service',
    'Service_Name'=>'Service_Name',
    'add_Service'=>'add_Service',
    'ServiceName_ar'=>'ServiceName_ar',
    'ServiceName_en'=>'ServiceName_en',
    'Service_desc'=>'Service_desc',
    'Processes'=>'Processes',
    'Close'=>'Close',
    'submit'=>'submit',
    'exists'=>'Data Alerady Exists',
    'Edit'=>'Edit',
     'delete_service'=>'delete_service',
    'Are you sure want to delete service'=>'Are you sure want to delete service ؟',
    'Delete'=>'Delete',
    'Cancel'=>'Cancel',
    'Message_Delete'=>'Data Deleted Successfuly',


];
