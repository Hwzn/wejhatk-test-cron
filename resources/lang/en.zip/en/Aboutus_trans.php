<?php
return[
  'aboutus'=>'aboutus',
  'New_Define'=>'New_Define',
  'ar_desc'=>'decs_ar',
  'en_desc'=>'desc_en',
  'proccess'=>'proccess',
  'delete_define'=>'delete_define',
  'Delete'=>'Delete',
  'Cancel'=>'Cancel',
  'submit'=>'submit',
  'Message_Delete'=>'data deleted successfuly',
  'edit_define'=>'edit_define',

];