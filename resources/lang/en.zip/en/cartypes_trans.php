<?php
return[
  'car_types'=>'car_types',
  'car_typeslist'=>'car_typeslist',
  'add_cartype'=>'add_cartype',
  'delete_car'=>'delete_car',
  'car_type'=>'car_type',
  'status'=>'status',
  'name_ar'=>'name_ar',
  'name_en'=>'name_en',
  'edit_cartype'=>'edit_cartype',
  'Processes'=>'Processes',
  'NotActive'=>'NotActive',
  'Active'=>' Active',
  'Delete'=>'Delete',
  'Cancel'=>'Cancel',
  'submit'=>'submit',
'Close'=>'Close',

  
];