<?php
return[
    'TermsAndConditions'=>'TermsAndConditions',
    'dsec_ar'=>'Conditions_ar',
    'dsec_en'=>'Conditions_en',
];