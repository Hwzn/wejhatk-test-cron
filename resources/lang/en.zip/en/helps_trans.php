<?php
return[
    'Helps_Types'=>'Helps_Types',
    'Add_HelpType'=>'Add_HelpType',
    'Requests_Help'=>'Requests_Help',
    'helpname'=>'helpname',
    'ar_name'=>'name_ar',
    'en_name'=>'name_en',
    'edit_help'=>'edit_help ',
    'proccess'=>'proccess',
    'delete_helptype'=>'Delete Message',
    'Close'=>'Close',
    'submit'=>'submit',
    'Delete'=>'Delete',
    'Cancel'=>'Cancel',
    'Message_Delete'=>'Data Deleted Success',
    'exists'=>'Data Already Exists',
    'Edit'=>'Edit',
  
];