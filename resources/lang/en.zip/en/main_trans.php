<?php

return [

    'Dashboard'=>'Dashboard',
    'Dashboard_page'=>'Dashboard_page',
    'Main_title'=>'Wejhatak_App',
    'Wejhatak_App' => 'Wejhatak_App',
    'change_language'=>'change_language',
    'Services'=>'Services',
    'Services_list'=>'Services_list',
    'Home'=>'Home',
    'Settings'=>'Settings',
    'Users'=>'Users',
    'Copyright' => 'Copyright ',
    'Contactus'=>'Contactus',
    'Contactus_Messages'=>'Contactus_Messages',
    'Aboutus'=>'Aboutus',
    'ShowCommonQuestions'=>'CommonQuestions',
    'Helps'=>'Helps',
    'TermsAndConditions'=>'TermsAndConditions',
    'UsagePolicy'=>'UsagePolicy',
    'Settings'=>'Settings',
    'Currencies'=>'العملات',

];
