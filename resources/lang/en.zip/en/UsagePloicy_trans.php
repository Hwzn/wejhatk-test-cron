<?php
return[
    'UsagePolicy'=>'UsagePolicy',
    'dsec_ar'=>'dsec_ar',
    'dsec_en'=>'dsec_en',
];