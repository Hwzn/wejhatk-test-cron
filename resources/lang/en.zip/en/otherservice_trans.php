<?php
return[
'OtherServices'=> 'OtherServices',
'OtherServices list'=>'OtherServices list',
'add_OtherServices'=>'add_OtherServices',
'delete_OtherServices'=>'delete_OtherServices',
'name_ar'=>'name_ar',
'name_en'=>'name_en',
'edit_OtherServices'=>'edit_OtherServices',
'Processes'=>'Processes',
'Delete'=>'Delete',
'Cancel'=>'Cancel',
'submit'=>'submit',
'Close'=>'Close',

  
];