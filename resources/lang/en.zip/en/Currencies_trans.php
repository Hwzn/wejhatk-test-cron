<?php
return [
    'Currencies'=>'العملات',
    'add currency'=>'اضافة عملة',
    'edit currency'=>'تعديل عملة',
    'delete currency'=>'حذف عملة',

    'currency'=>'العمله',
    'short currency'=>'اختصار العملة',
     'Processes'=>'العمليات',
     'currency_ar'=>'العمله بالعربية',
     'currency_en'=>'العمله بالانجليزية',
    'currencysymbol_ar'=>'رمز العمله بالعربية',
    'currencysymbol_en'=>'رمز العمله بالانجليزية',
    'Close'=>'أغلاق',
    'submit'=>'حفظ',
    'Delete'=>'حذف',
    'Cancel'=>'الغاء',


];