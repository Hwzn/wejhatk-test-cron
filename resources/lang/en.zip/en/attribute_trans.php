<?php

return [

    'attrubites' => 'attrubites',
    'attrubites_list'=>'attrubites_list',
    'attrubiteslist_services'=>'attrubiteslist_services',
    'New_Attribute'=>'اضافة خاصيه',
    'Attribute_Name'=>'Attribute_Name',
    'Attribute_Type'=>'Attribute_Type',
    'AttributeName_ar'=>'AttributeName_ar',
    'AttributeName_en'=>'AttributeName_en',
    'add_attribute'=>'add_attribute',
    'delete_attribute'=>'delete_attribute',
    'Service_desc'=>'Service_desc',
    'Processes'=>'Processes',
    'Close'=>'Close',
    'Submit'=>'Submit',
    'exists'=>'data already exists',
    'Edit'=>'Edit',
    'delete_service'=>'delete_service',
    'Are you sure want to delete attrubite'=>'Are you sure want to delete attrubite ',
    'Delete'=>'Delete',
    'Cancel'=>'Cancel',
    'Message_Delete'=>'service deleted sucessfuly',


];
