<?php
return[

'preferred method communicate'=>'preferred method communicate',
'method communicate list'=>'method communicate list',
'preferred method name'=>'preferred method name',
'add_method communicate'=>'add_method communicate',
'delete_method communicate'=>'delete_method communicate',
'name_ar'=>'name_ar',
'name_en'=>'name_en',
'edit_method communicate'=>'edit_method communicate',
'Processes'=>'Processes',
'Delete'=>'Delete',
'Cancel'=>'Cancel',
'submit'=>'submit',
'Close'=>'Close',

  
];