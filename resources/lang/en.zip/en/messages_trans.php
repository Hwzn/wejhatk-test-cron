<?php

return [
    'success'=>'Data Saved Successfuly ',
    'Update'=>'Data Updated Successfuly',
    'Delete'=>'Data Deleted Successfuly',
    'Warning_Grade'=>'are you sure deleting ',
];
