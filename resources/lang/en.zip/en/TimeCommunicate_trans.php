<?php
return[

'preferred time communicate'=>'preferred time communicate',
'time communicate list'=>'time communicate list',
'time communicate'=>'preferred time',
'add_time communicate'=>'add_time communicate',
'delete_time communicate'=>'delete_time communicate',
'name'=>'time',
'edit_time communicate'=>'edit_time communicate',
'Processes'=>'Processes',
'Delete'=>'Delete',
'Cancel'=>'Cancel',
'submit'=>'submit',
'Close'=>'Close',

  
];