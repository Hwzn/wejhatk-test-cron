<?php
return[
'Consultion_Types'=>'Consultion_Types',
'Consultion_Types list'=>'Consultion_Types list',
'add_ConsultionType'=>'add_ConsultionType',
'delete_ConsultionType'=>'delete_ConsultionType',
'name_ar'=>'name_ar',
'name_en'=>'name_en',
'edit_ConsultionType'=>'edit_ConsultionType',
'Processes'=>'Processes',
'Delete'=>'Delete',
'Cancel'=>'Cancel',
'submit'=>'submit',
'Close'=>'Close',

  
];