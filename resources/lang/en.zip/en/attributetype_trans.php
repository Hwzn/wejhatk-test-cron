<?php

return [

    'attrubite_type' => 'attrubite_type',
    'attrubitetype_name' => 'attrubitetype_name',
    'attrubitetype_list'=>'attrubitetype_list',
    'Home'=>'Home',
    'New_typeAttribute'=>'New_typeAttribute',
    'delete_attributetype'=>'delete_attributetype',
    'Are you sure want to delete'=>'Are you sure want to delete',
    'edit_attributetype'=>'edit_attributetype',
    'Processes'=>'Processes',
    'Close'=>'Close',
    'Submit'=>'Submit',
    'exists'=>'data already exists',
    'Edit'=>'Edit',
    'delete_service'=>'delete_service',
    'Delete'=>'Delete',
    'Cancel'=>'Cancel',
    'Message_Delete'=>'service deleted sucessfuly',


];
