<?php

return [
'Dashboard'=>'Dashboard',
'Dashboard 01'=>'Dashboard 01',
'Grades'=>'Grades',
'Grades_List'=>'Grades_List',
'ClassesRooms'=>'ClassesRooms',
'ClassesRooms_List'=>'ClassesRoomsList',
'Sections'=>'Sections',
'Sections_List'=>'SectionsList',
'Parents'=>'Parents',
'List_Parents'=>'List_Parents',
'Add_Parent'=>'Add_Parent ',
'Teachers'=>'Teachers',
'List_Teachers'=>'List_Teachers',
'Students'=>'Students',
'add_Student'=>'add_Student',
'Student_Promotions'=>'Student_Promotions',
'Managment_Student_Promotions'=>'Managment_Student_Promotions',
'Student_information'=>'Student_information',
'Students_Graduated'=>'Students_Graduated',
	'Add_Graduated'=>'Add_Graduated',
	'Graduated_List'=>'Graduated_List',
	'Study Fees'=>'Study Fees',
	'Fees Type'=>'Fees Type',

];
