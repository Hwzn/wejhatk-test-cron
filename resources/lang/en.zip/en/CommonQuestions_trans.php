<?php
return[
  'CommonQuestions'=>'CommonQuestions',
  'question'=>'question',
  'answer'=>'answer',
  'status'=>'status',
  'New_Question'=>'New_Question',
  'add_question'=>'add_question',
  'question_ar'=>'question_ar',
  'question_en'=>'question_en',
  'answer_ar'=>'answer_ar',
  'answer_en'=>'answer_en',
  'Processes'=>'Processes',
  'NotActive'=>'NotActive',
  'Active'=>' Active',
  'Delete'=>'Delete',
  'Cancel'=>'Cancel',
'delete_question'=>'delete_question',

  
];