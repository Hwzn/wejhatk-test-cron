<?php
return[
    'TermsAndConditions'=>'الشروط والأحكام',
    'dsec_ar'=>'الشروط باللغة العربية',
    'dsec_en'=>'الشروط باللغة الانجليزية',
];