<?php
return[

'preferred time communicate'=>'وقت التواصل المفضلة',
'time communicate list'=>'أوقات التواصل المفضلة',
'preferred time'=>'وقت التواصل',
'add_time communicate'=>'إضافة وقت تواصل',
'delete_time communicate'=>'حذف وقت تواصل',
'name'=>'الوقت',
'edit_time communicate'=>'تعديل وقت تواصل',
'Processes'=>'العمليات',
'Delete'=>'حذف',
'Cancel'=>'الغاء',
'submit'=>'حفظ',
'Close'=>'اغلاق',

  
];