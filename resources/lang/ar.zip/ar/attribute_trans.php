<?php

return [

    'attrubites' => 'الخصائص',
    'attrubiteslist_services'=>'قائمة خصائص الخدمات',
    'New_Attribute'=>'اضافة خاصيه',
    'Attribute_Name'=>'اسم الخاصية',
    'Attribute_Type'=>'نوع الخاصية',
    'Edit_Attribute'=>'تعديل خاصية',
    'AttributeName_ar'=>'اسم الخاصيه بالعربية',
    'AttributeName_en'=>'اسم الخاصيه باللغة الانجليزية',
    'add_attribute'=>'اضافة خاصية',
    'delete_attribute'=>'حذف خاصيه',
    'Processes'=>'العمليات',
    'Close'=>'Close',
    'submit'=>'حفظ',
    'exists'=>'data already exists',
    'Edit'=>'Edit',
    'delete_service'=>'delete_service',
    'Are you sure want to delete attrubite'=>'هل انت متاكد من حذف الخاصية',
    'Delete'=>'حذف',
    'Cancel'=>'الغاء',
    'Message_Delete'=>'service deleted sucessfuly',


];
