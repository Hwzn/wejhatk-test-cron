<?php
return[
  'car_types'=>' انواع السيارات',
  'car_typeslist'=>'قائمة انواع السيارات',

  'add_cartype'=>'إضافة سيارة',
  'car_type'=>'نوع السيارة',
  'delete_car'=>'حذف سيارة',
  'status'=>'الحالة',
  'name_ar'=>'نوع السيارة بالعربية',
  'name_en'=>'نوع السيارة بالإنجليزية',
  'edit_cartype'=>'تعديل',
  'Processes'=>'العمليات',
  'NotActive'=>'غير  مفعل',
  'Active'=>' مفعل',
  'Delete'=>'حذف',
  'Cancel'=>'الغاء',
  'submit'=>'حفظ',
'Close'=>'اغلاق',

  
];