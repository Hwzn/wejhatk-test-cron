<?php
return[
  'CommonQuestions'=>'الأسئلة الشائعة',
  'question'=>'السؤال',
  'answer'=>'الأجابة',
  'status'=>'الحالة',
  'New_Question'=>'سؤال جديد',
  'add_question'=>'اضافة سوال',
  'question_ar'=>'السؤال بالعربية',
  'question_en'=>'السؤال بالانجليزية',
  'answer_ar'=>'الأجابة بالعربية',
  'answer_en'=>'الأجابة بالانجليزية',
  'Processes'=>'العمليات',
  'NotActive'=>'غير  مفعل',
  'Active'=>' مفعل',
  'Delete'=>'حذف',
  'Cancel'=>'الغاء',
  'Cancel'=>'الغاء',
'delete_question'=>'حذف سوال',

  
];