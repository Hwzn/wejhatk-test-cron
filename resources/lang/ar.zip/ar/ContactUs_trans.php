<?php
return[
    'Contact_us'=>'رسائل اتصل بنا',
    'Message_list'=>'قائمة الرسائل',
    'name'=>'اسم المرسل',
    'phone'=>'رقم التليفون',
    'message'=>'نص الرسالة',
    'Proccess'=>'العمليات',
    'show_message'=>'عرض الرسالة',
    'date_message'=>'تاريخ الرسالة',
];