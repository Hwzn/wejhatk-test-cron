<?php
return[
  'aboutus'=>'من نحن',
  'New_Define'=>'تعريف جديد',
  'ar_desc'=>'الوصف باللغة العربية',
  'en_desc'=>'الوصف باللغة الانجليزية',
  'proccess'=>'العمليات',
  'delete_define'=>'حذف التعريف',
  'Delete'=>'حذف',
  'Cancel'=>'الغاء',
  'submit'=>'حفظ',
  'Message_Delete'=>'تم الحذف بنجاح',
  'edit_define'=>'تعديل',

];