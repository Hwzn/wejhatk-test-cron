<?php
return[
'OtherServices'=> 'الخدمات الأخري',
'OtherServices list'=>'قائمة الخدمات الأخري',
'add_OtherServices'=>'إضافة خدمه أخري',
'delete_OtherServices'=>'حذف خدمه اخري',
'name_ar'=>'  اسم الخدمه الأخري بالعربية',
'name_en'=>'نوع الخدمه الأخري بالإنجليزية',
'edit_OtherServices'=>'تعديل في الخدمات الأخري',
'Processes'=>'العمليات',
'Delete'=>'حذف',
'Cancel'=>'الغاء',
'submit'=>'حفظ',
'Close'=>'اغلاق',

  
];