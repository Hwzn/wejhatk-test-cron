<?php

return [

    'New_Service' => 'خدمة جديدة',
    'Service_Name'=>'اسم الخدمة',
    'add_Service'=>'اضافة خدمة',
    'ServiceName_ar'=>'اسم الخدمة باللغة العربية',
    'ServiceName_en'=>'اسم الخدمة باللغة الانجليزية',
    'Service_desc'=>'وصف الخدمة',
    'Processes'=>'العمليات',
    'Close'=>'أغلاق',
    'submit'=>'حفظ',
    'exists'=>'البيانات موجودة مسبقة',
    'Edit'=>'تعديل',
     'delete_service'=>'حذف خدمة',
    'Are you sure want to delete service'=>'هل أنت متاكد من حذف الخدمة ؟',
    'Delete'=>'حذف',
    'Cancel'=>'الغاء',
    'Message_Delete'=>'تم حذف الخدمه بنجاح',


];
