<?php

return [

    'attrubite_type' => 'نوع الخصائص',
    'attrubitetype_name' => 'اسم نوع الخاصية',
    'attrubitetype_list'=>'قائمة انواع الخصائص',
    'Home'=>'الرئيسية',
    'New_typeAttribute'=>'اضافة نوع خاصيه',
    'delete_attributetype'=>'حذف نوع خاصية',
    'Are you sure want to delete'=>'هل انت متاكد من حذف ',
    'edit_attributetype'=>'تعديل نوع خاصية',
    'Processes'=>'العمليات',
    'Close'=>'Close',
    'Submit'=>'حفظ',
    'exists'=>'data already exists',
    'Edit'=>'Edit',
    'delete_service'=>'delete_service',
    'Delete'=>'حذف',
    'Cancel'=>'الغاء',
    'Message_Delete'=>'service deleted sucessfuly',


];
