<?php
return[
'Consultion_Types'=>'أنواع الإستشارات',
'Consultion_Types list'=>'قائمة أنواع الإستشارات',
'add_ConsultionType'=>'إضافة نوع إستشارة',
'delete_ConsultionType'=>'حذف نوع إستشارة',
'name_ar'=>' نوع الإستشارة بالعربية',
'name_en'=>'نوع الإستشارة بالإنجليزية',
'edit_ConsultionType'=>'تعديل نوع إستشارة',
'Processes'=>'العمليات',
'Delete'=>'حذف',
'Cancel'=>'الغاء',
'submit'=>'حفظ',
'Close'=>'اغلاق',

  
];