<?php

return [

    'Dashboard'=>'الرئيسية',
    'Dashboard_page'=>'لوحة التحكم',
    'Main_title'=>'تطبيق وجهتك',
    'Wejhatak_App' => 'تطبيق وجهنك',
    'change_language'=>'تغير اللغة',
    'Services'=>'الخدمات',
    'Services_list'=>'قائمة الخدمات ',
    'Home'=>'الرئيسية',
    'Settings'=>'الاعدادات',
    'Users'=>'المستخدمين',
    'Copyright' => 'جميع الحقوق محفوظة ',
    'Name_Programer' => 'سمير جمال مورا سوفت',
    'Contactus'=>'رسائل اتصل بنا',
    'Contactus_Messages'=>'قائمة الرسائل',
    'Aboutus'=>'من نحن',
    'ShowCommonQuestions'=>'الاسئلة الشائعة',
    'Helps'=>'المساعدة',
    'TermsAndConditions'=>'الشروط والأحكام',
     'UsagePolicy'=>'سياسة الإستخدام',
     'AdsSlideShow'=>'شاشة عرض الاعلانات',
     'Settings'=>'الإعدادت',
     'Currencies'=>'العملات',
];
