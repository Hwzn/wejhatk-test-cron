<?php

return [

    'Notifications' => 'الاشعارات',
    'Logoff' => 'تسجيل خروج',

];
