<?php
return[
   'AdsSlideShow'=>'شاشة عرض الاعلانات',
   'Ads_list'=>'قائمة الإعلانات',
   'New_Ads'=>'اعلان جديد',
   'add_Ads'=>'اضافة اعلان',
   'ads_photo'=>'صورة الاعلان',
   'delete_AdsSlideShow'=>'حذف اعلان',
    'Processes'=>'العمليات',
    'Close'=>'Close',
    'submit'=>'حفظ',
    'exists'=>'data already exists',
    'Edit'=>'Edit',
    'delete_service'=>'delete_service',
    'Are you sure want to delete attrubite'=>'هل انت متاكد من حذف الخاصية',
    'Delete'=>'حذف',
    'Cancel'=>'الغاء',
    'Message_Delete'=>'service deleted sucessfuly',
];