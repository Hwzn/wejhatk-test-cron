<?php
return[

'preferred method communicate'=>'طرق التواصل المفضلة',
'method communicate list'=>'قائمة التواصل المفضلة',
'preferred method name'=>'مسمى طريقة التواصل',
'add_method communicate'=>'إضافة طريقة تواصل',
'delete_method communicate'=>'حذف طريقة تواصل',
'name_ar'=>' طريقة التواصل بالعربية',
'name_en'=>'طريقة التواصل بالإنجليزية',
'edit_method communicate'=>'تعديل طريقة تواصل',
'Processes'=>'العمليات',
'Delete'=>'حذف',
'Cancel'=>'الغاء',
'submit'=>'حفظ',
'Close'=>'اغلاق',

  
];