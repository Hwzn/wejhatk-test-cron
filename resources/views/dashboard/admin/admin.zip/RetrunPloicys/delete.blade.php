<div class="modal fade" id="deleteModola_policy" tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title"
                                                    id="exampleModalLabel">
                                                    {{ trans('returnploicy_trans.delete_ploicy') }}
                                                </h5>
                                               
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                            <div class="form-header">

                                                </div>
                                                <div class="modal-btn delete-action">
                                                   <label class="badge badge-danger" name="policy_name" style="font-size: 18px;"></label>
                                                   <hr>

                                                   <br>
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <a href="javascript:void(0);" class="btn btn-primary policy-btn-del">{{__('CommonQuestions_trans.Delete')}}</a>
                                                        </div>
                                                        <div class="col-6">
                                                            <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">{{__('CommonQuestions_trans.Cancel')}}</a>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
















